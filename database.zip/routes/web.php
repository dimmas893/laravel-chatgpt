<?php

use App\Http\Controllers\ApiController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
// Route::get("/emoji", [ApiController::class, "index"]);
// Route::get('/chatgpt', [ApiController::class, 'index'])
//     ->name('chatgpt.index');
// Route::post('/chatgpt/ask', [ApiController::class, 'ask'])
//     ->name('chatgpt.ask');
Route::get('/chatbot', [ApiController::class, 'index'])->name('chatbot');
Route::post('/ask', [ApiController::class, 'ask']);
